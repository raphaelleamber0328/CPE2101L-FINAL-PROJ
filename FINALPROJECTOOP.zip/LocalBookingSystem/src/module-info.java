/**
 * 
 */
/**
 * 
 */
module LocalBookingSystem {
	requires java.desktop;
}